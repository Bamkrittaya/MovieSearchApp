import heroImage from "../assets/MovieHero.png"; // Adjust the path to your image
import './style.css'; 

function HomePage() {
  return (
    <div className="hero-section">
    <div className="hero-heading">
    <h1>Welcome Movie Search Website!</h1>
    <h1>By Krittya Kruapat</h1>
    <p>Thank you for visiting! Enjoy browsing and discovering something new!</p>
    </div>
    </div>
  );
}
  export default HomePage;
  